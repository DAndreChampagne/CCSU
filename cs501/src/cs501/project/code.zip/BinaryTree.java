package cs501.project;

public class BinaryTree<T> {
	
	// to reuse the class, Previous will be left, Next will be right.
	Node<T> _root;
	
	public String TraversePreorder() {
		return null;
	}
	
	public String TraversePostorder() {
		return null;
	}
	
	public String TraverseInorder() {
		return null;
	}

	public String TraverseBreathFirst() {
		return TraverseLevelOrder();
	}
	
	public String TraverseLevelOrder() {
		return null;
	}
	
}
