package cs501.project;

public enum PathAlgorithm {
//	Dijkstra,
	AStar,
	//LPAStar,
}
